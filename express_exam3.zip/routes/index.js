const express = require('express');
const memberRouter = require("./member");
const orderRouter = require("./order");
const router = express.Router();
const fileRouter = require('./file');

router.use((req, res, next) => {
	// console.log(req.headers);
	// res.cookie("name", "david");
	// console.log(req.headers);
	// console.log("삭제 전 : ", req.cookies);
	// res.clearCookie("name", "david");
	// console.log("삭제 후 : ", req.cookies);
	// req.session.name = "david";
	// req.session.age = 40;
	// console.log(req.session);
	// console.log(req.session.name);
	// delete req.session.age;
	// console.log(req.session);
	// req.session.destory();
	// console.log(req.session);
	next();
})

/** 
* 회원 관련 URL
* /member/join, /member/login
*/
router.use("/member", memberRouter);


/**
* 주문 관련
* /order/cart, /order/form
*/
router.use("/order", orderRouter);

/**
* 파일 관련
* /file
*/
router.use("/file", fileRouter);

module.exports = router; 